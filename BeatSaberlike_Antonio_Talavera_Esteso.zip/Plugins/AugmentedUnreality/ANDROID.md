
"Path does not start with a valid root"

	Should be an C++ project with Build.cs

	"I created an empty C++ file so it would generate the Build.cs file, I added the OpenCV declarations and the AugmentedUnreality decleration, it works now. I just have to figure out how to get the Android camera feed to the camera."

	https://github.com/adynathos/AugmentedUnreality/issues/14

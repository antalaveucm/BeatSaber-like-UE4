
Install gstreamer
	- Install gstreamer and gstreamer-devel
	- set GSTREAMER_DIR
	- add to path?
	- ThirdParty/gstreamer/install.py

Build opencv

Package with rsync

